<?php
/*
Plugin Name: Login Registration
Description: Simple login registration plugin.
Version: 1.0
Author: Hardik Mandaliya
*/
add_action('wp_head','jquery_func');
function jquery_func(){?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<?php
}

//admin menu
add_action('admin_menu','login_menu_fun');
function login_menu_fun(){
	add_menu_page(
		'Login & Registration',
		'Login',
		'edit_posts',
		'login-registration',
		'page_login_function',
		'dashicons-universal-access'
	);
}

//plugin page
function page_login_function(){
?>
<h3>For Login Registration use below Shortcode.</h3>
<p>Login Shortcode: [user_login]</p>
<p>Registration Shortcode: [user_registration]</p>
<?php
}


//shortcode for login page form
add_shortcode('user_login','user_login_fun');
function user_login_fun(){
ob_start();
?>
<form method="post" id="login" enctype="multipart/form-data">
	<div class="email">
		<label>Email</label>
		<input type="email" name="email" id="email">
	</div>	
	<div class="password">
		<label>Password</label>
		<input type="password" name="password" id="Password">
	</div>
	<input type="submit" name="submit">
</form>
<script>
jQuery(document).ready(function(){
  jQuery("input[name='submit']").on('click', function(event){
    event.preventDefault();
    var email = jQuery('#email').val();;
    var password = jQuery('#Password').val();;
 
    jQuery.ajax({
	type: "post",
	dataType: "json",
	url: '<?php echo  admin_url( 'admin-ajax.php' ); ?>',
	data: {
		email:email,
		pass:password,
		action: 'login_action'
	},
	success: function(msg){
		// console.log(window.location.origin)
		// console.log(msg.msg)
		if(msg.msg == "success"){
			window.location = 'http://localhost/practicalexam/';
		}
	}
	});
  });
});
</script>
<?php
$return = ob_get_clean();
return $return;
}

//plugin active create a login page
function login_page(){
	$login = array(
		'post_title'  =>  'Login',
		'post_content' => '[user_login]',
		'post_status'  => 'publish',
		'post_author' => 1,
		'post_type'  =>  'page',
	);

	wp_insert_post($login);
}
register_activation_hook(__FILE__, 'login_page');

//shortcode for registration page form
add_shortcode('user_registration','user_registration_func');
function user_registration_func(){
ob_start();
?>
<form method="post">
	<div class="form-wrap">		
		<div class="fname">
			<label>First name</label>
			<input type="text" name="firstname">
		</div>
		<div class="mname">
			<label>Middle name</label>
			<input type="text" name="middlename">
		</div>
		<div class="lname">
			<label>Last name</label>
			<input type="text" name="lastname">
		</div>
		<div class="mail">
			<label>Email</label>
			<input type="email" name="mail">
		</div>
		<div class="phumber">
			<label>Phone Number</label>
			<input type="Number" name="phonenumber">
		</div>
		<div class="address">
			<label>Address</label>
			<input type="textarea" name="address">
		</div>
		<div class="pw">
			<label>Password</label>
			<input type="password" name="Password">
		</div>
		<div class="cpw">
			<label>Confirm Password</label>
			<input type="Password" name="confirmpassword">
		</div>
		<input type="submit" name="submit">
	</div>
</form>

<script type="text/javascript">
	jQuery(document).ready(function(){
	  	jQuery("input[name='submit']").on('click', function(event){
		    event.preventDefault();
		    var firstname = jQuery('input[name="firstname"]').val();
		    var middlename = jQuery('input[name="middlename"]').val();
		    var lastname = jQuery('input[name="lastname"]').val();
		    var mail = jQuery('input[name="mail"]').val();
		    var phonenumber = jQuery('input[name="phonenumber"]').val();
		    var address = jQuery('input[name="address"]').val();
		    var Password = jQuery('input[name="Password"]').val();

		    jQuery.ajax({
			type: "post",
			dataType: "json",
			url: '<?php echo  admin_url( 'admin-ajax.php' ); ?>',
			data: {
				firstname : firstname,
				middlename : middlename,
				lastname : lastname,
				mail : mail,
				phonenumber : phonenumber,
				address : address,
				Password : Password,
				action: 'register_action'
			},
			});


	  	});
	});
</script>

<?php
$return = ob_get_clean();
return $return;
}


//plugin active create a registration page
function registration_page(){
	$registration = array(
		'post_title'  =>  'Registration',
		'post_content' => '[user_registration]',
		'post_status'  => 'publish',
		'post_author' => 1,
		'post_type'  =>  'page',
	);

	wp_insert_post($registration);
}
register_activation_hook(__FILE__, 'registration_page');

add_action( 'wp_ajax_login_action', 'login_action_callback' ); 
add_action( 'wp_ajax_nopriv_login_action', 'login_action_callback' ); 
function login_action_callback() {

	$email = $_POST['email'];

	$user = get_user_by( 'email', $email );

	$user_id = $user->ID;
	//$user_login = get_user_by( 'id', $user_id ); 
	if( $user ) {
		
		$url = get_site_url();
		wp_set_current_user( $user_id, $user->user_login );
		wp_set_auth_cookie( $user_id );
		do_action( 'wp_login', $user->user_login );
		
	}

	$array = array(
		'msg' => "success",
	);
	echo json_encode($array);

    exit;
}


//registration page create a new user
add_action( 'wp_ajax_register_action', 'register_action_callback' ); 
add_action( 'wp_ajax_nopriv_register_action', 'login_action_callback' ); 
function register_action_callback() {
	echo "<pre>";
	print_r($_POST);
	echo "</pre>";

	$login = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$lastname = $_POST['lastname'];
	$mail = $_POST['mail'];
	$phonenumber = $_POST['phonenumber'];
    $address = $_POST['address'];
    $Password = $_POST['Password'];

	$user_id = wp_create_user($login, $Password, $mail);

    if (!$user_id || is_wp_error($user_id)) {
        // TODO: Display an error message and don't proceed.
    }
    
    $userinfo = array(
        'ID' => $user_id,
        'first_name' => $login,
        'last_name' => $lastname,
    );

    // Update the WordPress User object with first and last name.
    wp_update_user($userinfo);

    // Add the company as user metadata
    update_usermeta($user_id, 'firstname', $login);
    update_usermeta($user_id, 'lastname', $lastname);
    update_usermeta($user_id, 'mail', $mail);
    update_usermeta($user_id, 'phonenumber', $phonenumber);
    update_usermeta($user_id, 'address', $address);



    wp_die();
}

